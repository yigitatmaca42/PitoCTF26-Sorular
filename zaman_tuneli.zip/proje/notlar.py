notlar = []

def ekle(n):
    notlar.append(n)
def sil(i):
    notlar.pop(i)
