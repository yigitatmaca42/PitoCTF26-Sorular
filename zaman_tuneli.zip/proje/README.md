# Pito Not Defteri

Basit bir not alma uygulamasi.

## Kurulum
pip install -r requirements.txt
python app.py
